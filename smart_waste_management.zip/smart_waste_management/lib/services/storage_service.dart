import 'package:shared_preferences/shared_preferences.dart';
import '../models/waste_request.dart';

class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  Future<void> saveRequest(WasteRequest request) async {
    List<String> requestsJson = _prefs.getStringList('requests') ?? [];
    requestsJson.add(request.toJson());
    await _prefs.setStringList('requests', requestsJson);
  }

  List<WasteRequest> getRequests() {
    List<String> requestsJson = _prefs.getStringList('requests') ?? [];
    return requestsJson.map((jsonStr) => WasteRequest.fromJson(jsonStr)).toList().reversed.toList();
  }

  Future<void> deleteRequest(String id) async {
    List<String> requestsJson = _prefs.getStringList('requests') ?? [];
    requestsJson.removeWhere((jsonStr) {
      final req = WasteRequest.fromJson(jsonStr);
      return req.id == id;
    });
    await _prefs.setStringList('requests', requestsJson);
  }

  Future<void> clearRequests() async {
    await _prefs.remove('requests');
  }

  bool getNotificationsEnabled() => _prefs.getBool('notifications_enabled') ?? true;
  Future<void> setNotificationsEnabled(bool value) async => await _prefs.setBool('notifications_enabled', value);

  bool getLocationEnabled() => _prefs.getBool('location_enabled') ?? true;
  Future<void> setLocationEnabled(bool value) async => await _prefs.setBool('location_enabled', value);

  bool getReminderEnabled() => _prefs.getBool('reminder_enabled') ?? true;
  Future<void> setReminderEnabled(bool value) async => await _prefs.setBool('reminder_enabled', value);
}
