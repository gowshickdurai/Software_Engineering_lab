class NotificationService {
  static List<String> getNotifications() {
    return [
      'Welcome to SmartWaste!',
      'Find nearby recycling centres using the Centres tab.',
      'Schedule your first pickup today.'
    ];
  }
}
