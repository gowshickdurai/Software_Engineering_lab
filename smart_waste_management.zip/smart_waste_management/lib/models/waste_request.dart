import 'dart:convert';

class WasteRequest {
  final String id;
  final String category;
  final String address;
  final String date;
  final String time;
  final String status;

  WasteRequest({
    required this.id,
    required this.category,
    required this.address,
    required this.date,
    required this.time,
    required this.status,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'category': category,
      'address': address,
      'date': date,
      'time': time,
      'status': status,
    };
  }

  factory WasteRequest.fromMap(Map<String, dynamic> map) {
    return WasteRequest(
      id: map['id'] ?? '',
      category: map['category'] ?? '',
      address: map['address'] ?? '',
      date: map['date'] ?? '',
      time: map['time'] ?? '',
      status: map['status'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory WasteRequest.fromJson(String source) =>
      WasteRequest.fromMap(json.decode(source));
}
