class RecyclingCentre {
  final String id;
  final String name;
  final String location;
  final String category;
  final double distance;
  final double rating;

  RecyclingCentre({
    required this.id,
    required this.name,
    required this.location,
    required this.category,
    required this.distance,
    required this.rating,
  });
}
