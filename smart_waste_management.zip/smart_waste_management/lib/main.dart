
import 'package:flutter/material.dart';
import 'package:workmanager/workmanager.dart';
import 'screens/main_screen.dart';
import 'theme/app_theme.dart';
import 'services/storage_service.dart';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    // Simulated background processing task
    debugPrint("Native background task running: $task");
    return Future.value(true);
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService().init();
  Workmanager().initialize(callbackDispatcher);
  Workmanager().registerPeriodicTask("syncTask", "syncTask");
  runApp(const SmartWasteApp());
}

class SmartWasteApp extends StatelessWidget {
  const SmartWasteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SmartWaste',
      theme: AppTheme.lightTheme,
      home: const MainScreen(),
    );
  }
}
