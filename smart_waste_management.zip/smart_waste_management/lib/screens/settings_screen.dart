
import 'package:flutter/material.dart';
import '../services/storage_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notifications = true;
  bool _location = true;
  bool _reminders = true;

  @override
  void initState() {
    super.initState();
    _notifications = StorageService().getNotificationsEnabled();
    _location = StorageService().getLocationEnabled();
    _reminders = StorageService().getReminderEnabled();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
        title: const Text('Settings'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_outlined),
                  title: const Text('Notifications'),
                  subtitle: Text('Receive app notifications', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                  value: _notifications,
                  activeTrackColor: const Color(0xFF0A7036),
                  activeThumbColor: Colors.white,
                  onChanged: (val) {
                    setState(() => _notifications = val);
                    StorageService().setNotificationsEnabled(val);
                  },
                ),
                const Divider(height: 1),
                SwitchListTile(
                  secondary: const Icon(Icons.location_on_outlined),
                  title: const Text('Location'),
                  subtitle: Text('Enable location services', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                  value: _location,
                  activeTrackColor: const Color(0xFF0A7036),
                  activeThumbColor: Colors.white,
                  onChanged: (val) {
                    setState(() => _location = val);
                    StorageService().setLocationEnabled(val);
                  },
                ),
                const Divider(height: 1),
                SwitchListTile(
                  secondary: const Icon(Icons.alarm),
                  title: const Text('Collection Reminder'),
                  subtitle: Text('Get pickup reminders', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                  value: _reminders,
                  activeTrackColor: const Color(0xFF0A7036),
                  activeThumbColor: Colors.white,
                  onChanged: (val) {
                    setState(() => _reminders = val);
                    StorageService().setReminderEnabled(val);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: const Text('About App'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {},
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.help_outline),
                  title: const Text('Help & Support'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {},
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.privacy_tip_outlined),
                  title: const Text('Privacy Policy'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {},
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
