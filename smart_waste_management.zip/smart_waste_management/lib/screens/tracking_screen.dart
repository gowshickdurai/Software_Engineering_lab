
import 'package:flutter/material.dart';
import '../models/waste_request.dart';

class TrackingScreen extends StatelessWidget {
  final WasteRequest request;

  const TrackingScreen({super.key, required this.request});

  @override
  Widget build(BuildContext context) {
    int currentStep = 1;
    if (request.status == 'Confirmed') currentStep = 2;
    if (request.status == 'Collected') currentStep = 3;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
        title: const Text('Tracking'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.green.shade100,
                      child: const Icon(Icons.eco, color: Colors.green),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${request.category} Waste', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          Text(request.address, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                          Text('${request.date} • ${request.time}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Current Status', style: TextStyle(fontWeight: FontWeight.bold)),
                Text('$currentStep/3', style: TextStyle(color: Colors.grey.shade600)),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green.shade100,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  request.status,
                  style: const TextStyle(color: Color(0xFF0A7036), fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                _buildDot(currentStep >= 1),
                _buildLine(currentStep >= 2),
                _buildDot(currentStep >= 2),
                _buildLine(currentStep >= 3),
                _buildDot(currentStep >= 3),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text('Requested', style: TextStyle(fontSize: 12, color: Colors.black)),
                Text('Confirmed', style: TextStyle(fontSize: 12, color: Colors.grey)),
                Text('Collected', style: TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
            const SizedBox(height: 32),
            const Text('Tracking Steps', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _buildStep('Request Submitted', 'Your pickup request has been received.', request.date, currentStep >= 1),
            _buildStep('Pickup Confirmed', 'Your collection will be prepared.', '', currentStep >= 2),
            _buildStep('Waste Collected', 'Waste has been collected successfully.', '', currentStep >= 3, isLast: true),
          ],
        ),
      ),
    );
  }

  Widget _buildDot(bool active) {
    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(
        color: active ? const Color(0xFF0A7036) : Colors.grey.shade300,
        shape: BoxShape.circle,
      ),
      child: active ? const Icon(Icons.check, color: Colors.white, size: 16) : null,
    );
  }

  Widget _buildLine(bool active) {
    return Expanded(
      child: Container(
        height: 2,
        color: active ? const Color(0xFF0A7036) : Colors.grey.shade300,
      ),
    );
  }

  Widget _buildStep(String title, String subtitle, String date, bool isCompleted, {bool isLast = false}) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Column(
            children: [
              Icon(
                isCompleted ? Icons.check_circle : Icons.radio_button_unchecked,
                color: isCompleted ? const Color(0xFF0A7036) : Colors.grey.shade300,
              ),
              if (!isLast) Expanded(child: Container(width: 2, color: Colors.grey.shade300)),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 24.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: isCompleted ? Colors.black : Colors.grey)),
                        const SizedBox(height: 4),
                        Text(subtitle, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                        if (date.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(date, style: TextStyle(color: Colors.grey.shade400, fontSize: 12)),
                        ]
                      ],
                    ),
                  ),
                  Text(
                    isCompleted ? 'Completed' : 'Pending',
                    style: TextStyle(color: isCompleted ? const Color(0xFF0A7036) : Colors.grey, fontSize: 12, fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
