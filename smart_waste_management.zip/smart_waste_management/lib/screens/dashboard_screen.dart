
import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../models/waste_request.dart';
import 'notifications_screen.dart';
import 'main_screen.dart';
import 'tracking_screen.dart';
import 'report_issue_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  WasteRequest? _latestRequest;

  @override
  void initState() {
    super.initState();
    _loadLatestRequest();
  }

  void _loadLatestRequest() {
    final requests = StorageService().getRequests();
    setState(() {
      _latestRequest = requests.isNotEmpty ? requests.first : null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.eco, color: Colors.white),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('SmartWaste', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text('Manage your waste responsibly.', style: TextStyle(fontSize: 12, color: Colors.white.withValues(alpha: 0.8))),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen()));
            },
          )
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => _loadLatestRequest(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Waste Categories', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1,
              children: [
                _buildCatCard('Organic', Icons.eco, Colors.green),
                _buildCatCard('Plastic', Icons.local_drink, Colors.blue),
                _buildCatCard('Paper', Icons.description, Colors.orange),
                _buildCatCard('Glass', Icons.wine_bar, Colors.teal),
                _buildCatCard('Metal', Icons.build, Colors.grey),
                _buildCatCard('E-Waste', Icons.computer, Colors.red),
              ],
            ),
            const SizedBox(height: 24),
            const Text('Quick Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 2.5,
              children: [
                _buildActionCard('Request Pickup', Icons.local_shipping_outlined, () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainScreen(initialIndex: 2)));
                }),
                _buildActionCard('Find Recycling\nCentres', Icons.location_on_outlined, () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainScreen(initialIndex: 1)));
                }),
                _buildActionCard('Track Collection', Icons.track_changes, () {
                  if (_latestRequest != null) {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => TrackingScreen(request: _latestRequest!)));
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No active requests to track.')));
                  }
                }),
                _buildActionCard('Report Issue', Icons.report_problem_outlined, () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportIssueScreen()));
                }),
              ],
            ),
            const SizedBox(height: 24),
            const Text('Latest Request', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _latestRequest != null
                ? Card(
                    key: const Key('latest_request_card'),
                    child: ListTile(
                      leading: const Icon(Icons.receipt_long, color: Colors.green),
                      title: Text('${_latestRequest!.category} Waste', style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${_latestRequest!.date} • ${_latestRequest!.status}'),
                    ),
                  )
                : Card(
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        children: [
                          Icon(Icons.edit_note, size: 48, color: Colors.grey.shade400),
                          const SizedBox(height: 8),
                          const Text('No waste pickup requests yet.', style: TextStyle(fontWeight: FontWeight.bold)),
                          Text('Create your first request', style: TextStyle(color: Colors.grey.shade600)),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: () {
                              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainScreen(initialIndex: 2)));
                            },
                            child: const Text('Request Pickup'),
                          )
                        ],
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildCatCard(String title, IconData icon, Color color) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _buildActionCard(String title, IconData icon, VoidCallback onTap) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              Icon(icon, color: const Color(0xFF0A7036), size: 20),
              const SizedBox(width: 8),
              Expanded(child: Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
            ],
          ),
        ),
      ),
    );
  }
}
