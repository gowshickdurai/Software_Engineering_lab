import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/location_service.dart';

class ReportIssueScreen extends StatefulWidget {
  const ReportIssueScreen({super.key});

  @override
  State<ReportIssueScreen> createState() => _ReportIssueScreenState();
}

class _ReportIssueScreenState extends State<ReportIssueScreen> {
  final _descController = TextEditingController();
  final _addressController = TextEditingController();

  Future<void> _getLocation() async {
    final pos = await LocationService.getCurrentLocation();
    if (pos != null && mounted) {
      setState(() {
        _addressController.text = '${pos.latitude}, ${pos.longitude}';
      });
    }
  }

  Future<void> _sendEmail() async {
    final subject = Uri.encodeComponent('Garbage Collection Issue');
    final body = Uri.encodeComponent('Location: ${_addressController.text}\n\nIssue: ${_descController.text}');
    final url = Uri.parse('mailto:support@smartwaste.com?subject=$subject&body=$body');
    if (!await launchUrl(url)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open email app')));
    }
  }

  Future<void> _sendSMS() async {
    final body = Uri.encodeComponent('Garbage Collection Issue at ${_addressController.text}: ${_descController.text}');
    final url = Uri.parse('sms:1234567890?body=$body');
    if (!await launchUrl(url)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open SMS app')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
        title: const Text('Report Issue'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Problem Location', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextFormField(
              controller: _addressController,
              decoration: const InputDecoration(hintText: 'Enter address or use GPS'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _getLocation,
              icon: const Icon(Icons.my_location),
              label: const Text('Use GPS Location'),
            ),
            const SizedBox(height: 16),
            const Text('Issue Description', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextFormField(
              controller: _descController,
              maxLines: 4,
              decoration: const InputDecoration(hintText: 'Describe the problem (e.g. missed pickup, spilled garbage)'),
            ),
            const SizedBox(height: 32),
            const Text('Alert Authorities via', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue.shade700),
                    onPressed: _sendSMS,
                    icon: const Icon(Icons.sms),
                    label: const Text('Send SMS'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade700),
                    onPressed: _sendEmail,
                    icon: const Icon(Icons.email),
                    label: const Text('Send Email'),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
