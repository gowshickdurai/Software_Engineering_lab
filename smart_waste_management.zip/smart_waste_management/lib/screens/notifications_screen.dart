
import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
        title: const Text('Notifications'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildNotif(Icons.notifications_active, 'Pickup request submitted', 'Your waste pickup request has been submitted successfully.', '2h ago'),
          _buildNotif(Icons.local_shipping, 'Pickup confirmed', 'Your pickup has been confirmed for May 25, 2025.', '5h ago'),
          _buildNotif(Icons.calendar_today, 'Collection reminder', 'Your waste will be collected tomorrow at 10:00 AM.', '1d ago'),
          _buildNotif(Icons.check_circle, 'Waste collected', 'Your waste has been collected successfully.', '2d ago'),
          _buildNotif(Icons.location_on, 'Recycling centre info', 'New recycling centre "Green Earth" added near you.', '3d ago'),
        ],
      ),
    );
  }

  Widget _buildNotif(IconData icon, String title, String desc, String time) {
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              backgroundColor: Colors.green.shade50,
              child: Icon(icon, color: Colors.green),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(desc, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                ],
              ),
            ),
            Text(time, style: TextStyle(color: Colors.grey.shade400, fontSize: 12)),
          ],
        ),
        const Divider(height: 32),
      ],
    );
  }
}
